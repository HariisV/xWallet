"use strict";
exports.id = 304;
exports.ids = [304];
exports.modules = {

/***/ 9390:
/***/ ((module) => {


module.exports = {
    reactStrictMode: true,
    env: {
        URL_BACKEND: "https://xwallet-backend.dokumensaya.com",
        URL_FRONTEND: "http://localhost:3000"
    },
    async rewrites () {
        return [
            {
                source: "/profile",
                destination: "/main/profile"
            }, 
        ];
    }
};


/***/ }),

/***/ 7304:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9390);
/* harmony import */ var next_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_config__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
js_cookie__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const axiosApiIntances = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseURL: "https://xwallet-backend.dokumensaya.com"
});
// Add a request interceptor
axiosApiIntances.interceptors.request.use(function(config) {
    // Do something before request is sent
    if (js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("token")) {
        config.headers = {
            Authorization: `Bearer ${js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("token")}`
        };
    }
    return config;
}, function(error) {
    // Do something with request error
    return Promise.reject(error);
});
// Add a response interceptor
axiosApiIntances.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    if (error.response.status === 403) {
        js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].remove("token");
        js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].remove("id");
        if (js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("token")) {
            alert(error.response.data.msg);
            window.location.href = "/login";
        }
    }
    return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosApiIntances);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;