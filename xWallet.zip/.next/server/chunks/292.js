exports.id = 292;
exports.ids = [292];
exports.modules = {

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"balance": "Home_balance___HU_4",
	"total": "Home_total__212AA",
	"phone": "Home_phone__F9sBR",
	"transaction__desc": "Home_transaction__desc__Cvj99",
	"name": "Home_name__Je8n6",
	"type": "Home_type__xsxUb",
	"transfer": "Home_transfer__pAWL0",
	"topup": "Home_topup__YAPwZ",
	"pending": "Home_pending__d_IvT"
};


/***/ }),

/***/ 1682:
/***/ ((module) => {

// Exports
module.exports = {
	"input__filter": "Transfer_input__filter__GjVue",
	"input__icon": "Transfer_input__icon__XrPhY",
	"transfer__text": "Transfer_transfer__text__80kNI",
	"input__nominal": "Transfer_input__nominal__4yjlW",
	"total__available": "Transfer_total__available__swGGU",
	"transfer__transfer__title": "Transfer_transfer__transfer__title__HgFB7",
	"transfer__transfer__value": "Transfer_transfer__transfer__value__AFg0V",
	"transfer__transfer__name": "Transfer_transfer__transfer__name__wRM5d",
	"group": "Transfer_group__VaPaS",
	"btn": "Transfer_btn__96K6o",
	"modal__title": "Transfer_modal__title__VznPS",
	"modal__border": "Transfer_modal__border__gBCPy",
	"transfer__transfer__text": "Transfer_transfer__transfer__text__HVGZL",
	"btn_close": "Transfer_btn_close__4j2Ef"
};


/***/ }),

/***/ 5172:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Index)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1288);
/* harmony import */ var styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3__);




function Index(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "d-flex mb-5 mt-4 justify-content-between",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: props.image ? `${"https://xwallet-backend.dokumensaya.com"}/uploads/${props.image}` : "/image/avatard.png",
                    alt: "",
                    width: "50px",
                    className: "mrgin-3",
                    height: "50px"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-block link__transfer",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/transfer/${props.id}`,
                            className: "bg-primary",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: `p-0 m-0 ${(styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default().name)}`,
                                children: props.name
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                            className: `${(styles_Home_module_css__WEBPACK_IMPORTED_MODULE_3___default().type)}`,
                            children: props.noTelp
                        })
                    ]
                })
            ]
        })
    });
}


/***/ })

};
;