(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: external "redux-logger"
const external_redux_logger_namespaceObject = require("redux-logger");
var external_redux_logger_default = /*#__PURE__*/__webpack_require__.n(external_redux_logger_namespaceObject);
;// CONCATENATED MODULE: external "redux-promise-middleware"
const external_redux_promise_middleware_namespaceObject = require("redux-promise-middleware");
var external_redux_promise_middleware_default = /*#__PURE__*/__webpack_require__.n(external_redux_promise_middleware_namespaceObject);
;// CONCATENATED MODULE: ./stores/reducer/auth.js
const initialState = {
    idUser: "",
    isError: false,
    isLoading: false,
    msg: "",
    userLogin: {},
    isPin: ""
};
const login = (state = initialState, action)=>{
    switch(action.type){
        case "LOGIN_PENDING":
            {
                return {
                    ...state,
                    isLoading: true,
                    isError: false
                };
            }
        case "LOGIN_FULFILLED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: false,
                    isPin: action.payload.data.data.pin,
                    idUser: action.payload.data.data.id,
                    msg: action.payload.data.msg
                };
            }
        case "LOGIN_REJECTED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: true,
                    idUser: "",
                    msg: action.payload.response.data.msg
                };
            }
        case "GETUSER_PENDING":
            {
                return {
                    ...state,
                    isLoading: true,
                    isError: false
                };
            }
        case "GETUSER_FULFILLED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: false,
                    idUser: action.payload.data.data.id,
                    msg: action.payload.data.msg,
                    userLogin: action.payload.data.data
                };
            }
        case "GETUSER_REJECTED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: true,
                    idUser: "",
                    msg: action.payload.response.data.msg
                };
            }
        default:
            {
                return state;
            }
    }
};
/* harmony default export */ const auth = (login);

;// CONCATENATED MODULE: ./stores/reducer/history.js
const history_initialState = {
    isError: false,
    isLoading: false,
    msg: "",
    data: {},
    pageInfo: {}
};
const Historys = (state = history_initialState, action)=>{
    switch(action.type){
        case "GETHISTORY_PENDING":
            {
                return {
                    ...state,
                    isLoading: true,
                    isError: false
                };
            }
        case "GETHISTORY_FULFILLED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: false,
                    data: action.payload.data.data,
                    pageInfo: action.payload.data.pagination,
                    msg: action.payload.data.msg
                };
            }
        case "GETHISTORY_REJECTED":
            {
                return {
                    ...state,
                    isLoading: false,
                    isError: true,
                    data: {},
                    msg: action.payload.response.data.msg
                };
            }
        default:
            {
                return state;
            }
    }
};
/* harmony default export */ const reducer_history = (Historys);

;// CONCATENATED MODULE: ./stores/reducer/index.js



/* harmony default export */ const reducer = ((0,external_redux_namespaceObject.combineReducers)({
    auth: auth,
    history: reducer_history
}));

;// CONCATENATED MODULE: ./stores/store.js






const persistConfig = {
    key: "root",
    storage: (storage_default())
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, reducer);
const store = (0,external_redux_namespaceObject.createStore)(persistedReducer, (0,external_redux_namespaceObject.applyMiddleware)((external_redux_promise_middleware_default()), (external_redux_logger_default())));
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);


;// CONCATENATED MODULE: external "redux-persist/integration/react"
const react_namespaceObject = require("redux-persist/integration/react");
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./pages/_app.js









function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
            store: store,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.PersistGate, {
                loading: null,
                persistor: persistor,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                        src: "https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                                rel: "preconnect",
                                href: "https://fonts.googleapis.com"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                                rel: "preconnect",
                                href: "https://fonts.gstatic.com",
                                crossOrigin: true
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("style", {
                                "data-href": "https://fonts.googleapis.com/css2?family=Nunito:wght@200;400;600;700;800;900&display=swap"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                name: "viewport",
                                content: "width=device-width, initial-scale=1"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(699)


/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [907,699], () => (__webpack_exec__(5725)));
module.exports = __webpack_exports__;

})();