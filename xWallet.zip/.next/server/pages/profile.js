(() => {
var exports = {};
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ 1157:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar__image": "Profile_navbar__image__7kTc9",
	"geser": "Profile_geser__KzxQw",
	"btn__list": "Profile_btn__list__r5vyf",
	"btn__detail": "Profile_btn__detail__Ad9Lg",
	"nama__user": "Profile_nama__user__mab_7",
	"mobile__user": "Profile_mobile__user__YKMom",
	"group": "Profile_group__6lra1",
	"detail__name": "Profile_detail__name__pNYxS",
	"detail__value": "Profile_detail__value__vhEar",
	"title": "Profile_title___Iua8",
	"desc": "Profile_desc__rVft4",
	"input": "Profile_input__6OU5O",
	"input_span": "Profile_input_span__GWwQ2",
	"primary": "Profile_primary__c0Gfa",
	"containerr": "Profile_containerr__2oLay",
	"btn_close": "Profile_btn_close__bGz2Z"
};


/***/ }),

/***/ 8156:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7304);
/* harmony import */ var components_layout_notify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2036);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_2__]);
utils_axios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const inputStyle = {
    width: "50px",
    height: "65px",
    background: "#FFFFFF",
    border: "1px solid rgba(169, 169, 169, 0.6)",
    boxSizing: "border-box",
    boxShadow: "0px 10px 75px rgba(147, 147, 147, 0.1)",
    borderRadius: "10px"
};
const inputContainer = {
    width: "100%"
};
function Personalinfo(props) {
    const { 0: pin , 1: setPin  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const addPin = (event)=>{
        if (event.target.value) {
            const nextSibling = document.getElementById(`pin-${parseInt(event.target.name, 10) + 1}`);
            if (nextSibling !== null) {
                nextSibling.focus();
            }
        }
        setPin({
            ...pin,
            [`pin${event.target.name}`]: event.target.value
        });
    };
    const handleSubmit = ()=>{
        const allPin = pin.pin1 + pin.pin2 + pin.pin3 + pin.pin4 + pin.pin5 + pin.pin6;
        // const setData = {
        //   pin: allPin,
        // };
        utils_axios__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`/user/pin?pin=${allPin}`).then((res)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_3__/* .Notify */ .g)("Pin Benar !", 200);
            props.changePage("ManagePin");
        }).catch((err)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_3__/* .Notify */ .g)(err.response.data.msg, 400);
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3 ppp",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default().title)}`,
                            children: "Check Pin"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `btn text-white  ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default().btn_close)} `,
                            onClick: ()=>props.changePage("Index"),
                            children: "X"
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default().desc)}`,
                    children: [
                        "Enter your current 6 digits Zwallet PIN below to ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " continue to the next steps.",
                        " "
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-flex justify-content-center mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default().containerr)}`,
                        children: [
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: inputContainer,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "1",
                                                id: "pin-1"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "2",
                                                id: "pin-2"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                required: true,
                                                onChange: (event)=>addPin(event),
                                                name: "3",
                                                id: "pin-3"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "4",
                                                id: "pin-4"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "5",
                                                id: "pin-5"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "6",
                                                id: "pin-6"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `btn btn-primary  mb-5 w-100 ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_4___default().primary)} mt-5`,
                                onClick: handleSubmit,
                                children: "Continue"
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 839:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7304);
/* harmony import */ var components_layout_notify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2036);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9915);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_5__]);
([utils_axios__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function Personalinfo(props) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const inputFile = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: formImage , 1: setFormImage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        image: ""
    });
    const handleLogout = ()=>{
        localStorage.clear();
        js_cookie__WEBPACK_IMPORTED_MODULE_5__["default"].remove("token", {
            path: ""
        });
        router.push("/auth/login");
    };
    const onButtonClick = ()=>{
        inputFile.current.click();
    };
    const handleChangeImage = (event)=>{
        if (event.target.files && event.target.files[0]) {
            // const { name, value } = event.target;
            const formData = new FormData();
            formData.append("image", event.target.files[0]);
            utils_axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"].patch */ .Z.patch(`/user/image/${props.data.id}`, formData).then((res)=>{
                props.dispatch(props.data.id);
                (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_4__/* .Notify */ .g)("Berhasil Mengganti Image Profile!", 200);
            }).catch((err)=>{
            // err.response.data.msg && Notify(err.response.data.msg, 400);
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3 text-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: props.data.image ? `${"https://xwallet-backend.dokumensaya.com"}/uploads/${props.data.image}` : "/image/avatard.png",
                    className: ` ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().navbar__image)}`,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-flex justify-content-center mt-3",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "btn btn-light text-black",
                        onClick: onButtonClick,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/icon/edit.svg",
                                alt: "",
                                width: 13,
                                height: 13
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "file",
                                id: "file",
                                ref: inputFile,
                                onChange: handleChangeImage,
                                style: {
                                    display: "none"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: `align-self-center ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().geser)}`,
                                children: "Edit"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().nama__user)}`,
                    children: props.data.firstName + " " + props.data.lastName
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().mobile__user)}`,
                    children: [
                        props.data.noTelp ? props.data.noTelp : "+62 xxxx xxxx xxxx",
                        " "
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__list)} btn mt-5 `,
                    onClick: ()=>props.changePage("personalInfo"),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `d-flex justify-content-between ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__detail)}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Personal Information"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/icon/arrow-left.svg",
                                alt: ""
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__list)} btn `,
                    onClick: ()=>props.changePage("ManagePassword"),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `d-flex justify-content-between ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__detail)}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Change Password"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/icon/arrow-left.svg",
                                alt: ""
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__list)} btn `,
                    onClick: ()=>props.changePage("CheckPin"),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `d-flex justify-content-between ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__detail)}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Change PIN"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/icon/arrow-left.svg",
                                alt: ""
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_7___default().btn__list)} btn `,
                    onClick: handleLogout,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        style: {
                            textAlign: "start",
                            fontWeight: "600"
                        },
                        className: "p-0 m-0",
                        children: "Logout"
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ index)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_2__);



function index(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `input-group ${props.isInvalid ? "mb-2" : "mb-4"}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `input-group-text ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_2___default().input_span)}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: props.icon,
                    alt: ""
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: props.type,
                className: `form-control ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_2___default().input)} ${props.isInvalid ? "is-invalid" : ""}`,
                placeholder: props.placeholder,
                value: props.value,
                name: props.name,
                onChange: (e)=>props.onChange ? props.onChange(e) : null
            })
        ]
    });
}


/***/ }),

/***/ 3470:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_profile_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7155);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7304);
/* harmony import */ var components_layout_notify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2036);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_4__]);
utils_axios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Personalinfo(props) {
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const handleSubmit = (e)=>{
        const setData = {
            oldPassword: form.oldPassword,
            newPassword: form.newPassword,
            confirmPassword: form.confirmPassword
        };
        utils_axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].patch */ .Z.patch(`/user/password/${props.data.id}`, setData).then((res)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_5__/* .Notify */ .g)("Berhasil Mengubah Password !", 200);
            props.dispatch(props.data.id);
        }).catch((err)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_5__/* .Notify */ .g)(err.response.data.msg, 400);
        });
    };
    const handleChange = (e)=>{
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().title)}`,
                            children: "Change Password"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `btn text-white  ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().btn_close)} `,
                            onClick: ()=>props.changePage("Index"),
                            children: "X"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().desc)}`,
                    children: [
                        "You must enter your current password and then ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " type your new password twice."
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-flex justify-content-center mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().containerr)}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_input__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                placeholder: "Current password",
                                icon: "/icon/lock.svg",
                                type: "password",
                                name: "oldPassword",
                                onChange: handleChange
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_input__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                placeholder: "New password",
                                icon: "/icon/lock.svg",
                                type: "password",
                                name: "newPassword",
                                onChange: handleChange
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_input__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                placeholder: "Repeat new password",
                                icon: "/icon/lock.svg",
                                type: "password",
                                name: "confirmPassword",
                                onChange: handleChange
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `btn btn-primary w-100 ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().primary)} mt-5`,
                                onClick: handleSubmit,
                                children: "Change Password"
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1471:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_profile_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7155);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7304);
/* harmony import */ var components_layout_notify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2036);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_4__]);
utils_axios__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Personalinfo(props) {
    const { 0: form , 1: setForm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        phone: props.data.noTelp
    });
    const handleSubmit = ()=>{
        const setData = {
            noTelp: form.phone
        };
        utils_axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"].patch */ .Z.patch(`user/profile/${props.data.id}`, setData).then((res)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_5__/* .Notify */ .g)("Berhasil Mengapdate Nomor Telepon !", 200);
            props.dispatch(props.data.id);
        }).catch((err)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_5__/* .Notify */ .g)(err.response.data.msg, 400);
        });
    };
    const handleChange = (e)=>{
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow height",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().title)}`,
                            children: "Update Phone Number"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `btn text-white  ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().btn_close)} `,
                            onClick: ()=>props.changePage("Index"),
                            children: "X"
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().desc)}`,
                    children: [
                        "Add at least one phone number for the transfer ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " ID so you can start transfering your money to ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " another user.",
                        " "
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-flex justify-content-center mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().containerr)}`,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `input-group`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: `input-group-text ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().input_span)}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/icon/phone.svg",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "number",
                                        className: `form-control ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)}`,
                                        placeholder: "Enter your phone number",
                                        name: "phone",
                                        value: form.phone,
                                        onChange: handleChange
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `btn btn-primary w-100 ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_6___default().primary)} mt-5`,
                                onClick: handleSubmit,
                                children: "Change Password"
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7515:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var components_profile_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7155);
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7304);
/* harmony import */ var components_layout_notify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2036);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_3__]);
utils_axios__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const inputStyle = {
    width: "50px",
    height: "65px",
    background: "#FFFFFF",
    border: "1px solid rgba(169, 169, 169, 0.6)",
    boxSizing: "border-box",
    boxShadow: "0px 10px 75px rgba(147, 147, 147, 0.1)",
    borderRadius: "10px"
};
const inputContainer = {
    width: "100%"
};
function Personalinfo(props) {
    const { 0: pin , 1: setPin  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const addPin = (event)=>{
        if (event.target.value) {
            const nextSibling = document.getElementById(`pin-${parseInt(event.target.name, 10) + 1}`);
            if (nextSibling !== null) {
                nextSibling.focus();
            }
        }
        setPin({
            ...pin,
            [`pin${event.target.name}`]: event.target.value
        });
    };
    const handleSubmit = ()=>{
        const allPin = pin.pin1 + pin.pin2 + pin.pin3 + pin.pin4 + pin.pin5 + pin.pin6;
        const setData = {
            pin: allPin
        };
        utils_axios__WEBPACK_IMPORTED_MODULE_3__/* ["default"].patch */ .Z.patch(`/user/pin/${props.data.id}`, setData).then((res)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_4__/* .Notify */ .g)("Berhasil Mengganti Pin !", 200);
            props.changePage("Index");
        }).catch((err)=>{
            (0,components_layout_notify__WEBPACK_IMPORTED_MODULE_4__/* .Notify */ .g)(err.response.data.msg, 400);
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3 ppp",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default().title)}`,
                            children: "Change PIN"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `btn text-white  ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default().btn_close)} `,
                            onClick: ()=>props.changePage("Index"),
                            children: "X"
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default().desc)}`,
                    children: [
                        "Type your new 6 digits security PIN to use in ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " Zwallet."
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "d-flex justify-content-center mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default().containerr)}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: inputContainer,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "1",
                                                id: "pin-1"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "2",
                                                id: "pin-2"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                required: true,
                                                onChange: (event)=>addPin(event),
                                                name: "3",
                                                id: "pin-3"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "4",
                                                id: "pin-4"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "5",
                                                id: "pin-5"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                style: inputStyle,
                                                className: "input__pin",
                                                maxLength: "1",
                                                onChange: (event)=>addPin(event),
                                                name: "6",
                                                id: "pin-6"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `btn btn-primary  mb-5 w-100 ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_5___default().primary)} mt-5`,
                                onClick: handleSubmit,
                                children: "Change PIN"
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Personalinfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1157);
/* harmony import */ var styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3__);




function Personalinfo(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card card__shadow ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "card-body mx-3",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "d-flex justify-content-between",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().title)}`,
                            children: "Personal Information"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `btn text-white  ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().btn_close)} `,
                            onClick: ()=>props.changePage("Index"),
                            children: "X"
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().desc)}`,
                    children: [
                        "We got your personal information from the sign ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " up proccess. If you want to make changes on ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        " your information, contact our support."
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` card card-body ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().group)} mt-5 card__shadow_xl`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__name)}`,
                            children: "First Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__value)} p-0 m-0`,
                            children: props.data.firstName
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` card card-body ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().group)} card__shadow_xl`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__name)}`,
                            children: "Last Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__value)} p-0 m-0`,
                            children: props.data.lastName
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` card card-body ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().group)} card__shadow_xl`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__name)}`,
                            children: "Verified E-mail"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__value)} p-0 m-0`,
                            children: props.data.email
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` card card-body ${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().group)} card__shadow_xl`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                            className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__name)}`,
                            children: "Phone Number"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "d-flex justify-content-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: `${(styles_Profile_module_css__WEBPACK_IMPORTED_MODULE_3___default().detail__value)} p-0 m-0`,
                                    children: props.data.noTelp ? props.data.noTelp : "Belum Ditambahkan"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn",
                                    onClick: ()=>props.changePage("ManagePhone"),
                                    children: "Manage"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 6450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ getDataCookie)
/* harmony export */ });
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7486);
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_cookies__WEBPACK_IMPORTED_MODULE_0__);

function getDataCookie(context) {
    return new Promise((resolve)=>{
        let dataCookie = next_cookies__WEBPACK_IMPORTED_MODULE_0___default()(context);
        if (dataCookie.token) {
            dataCookie.isLogin = true;
        } else {
            dataCookie.isLogin = false;
        }
        resolve(dataCookie);
    });
}


/***/ }),

/***/ 2217:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3651);
/* harmony import */ var components_layout_navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3982);
/* harmony import */ var components_layout_footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4412);
/* harmony import */ var components_layout_sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3165);
/* harmony import */ var components_profile_personal_info__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7680);
/* harmony import */ var components_profile__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(839);
/* harmony import */ var components_profile_manage_password__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3470);
/* harmony import */ var components_profile_manage_pin__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7515);
/* harmony import */ var components_profile_check_pin__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8156);
/* harmony import */ var components_profile_manage_phone__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1471);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var stores_action_auth__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5536);
/* harmony import */ var middleware_authorizationPage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6450);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_layout_navbar__WEBPACK_IMPORTED_MODULE_3__, components_layout_sidebar__WEBPACK_IMPORTED_MODULE_5__, components_profile__WEBPACK_IMPORTED_MODULE_7__, components_profile_manage_password__WEBPACK_IMPORTED_MODULE_8__, components_profile_manage_pin__WEBPACK_IMPORTED_MODULE_9__, components_profile_check_pin__WEBPACK_IMPORTED_MODULE_10__, components_profile_manage_phone__WEBPACK_IMPORTED_MODULE_11__, stores_action_auth__WEBPACK_IMPORTED_MODULE_13__]);
([components_layout_navbar__WEBPACK_IMPORTED_MODULE_3__, components_layout_sidebar__WEBPACK_IMPORTED_MODULE_5__, components_profile__WEBPACK_IMPORTED_MODULE_7__, components_profile_manage_password__WEBPACK_IMPORTED_MODULE_8__, components_profile_manage_pin__WEBPACK_IMPORTED_MODULE_9__, components_profile_check_pin__WEBPACK_IMPORTED_MODULE_10__, components_profile_manage_phone__WEBPACK_IMPORTED_MODULE_11__, stores_action_auth__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















async function getServerSideProps(context) {
    const dataCookie = await (0,middleware_authorizationPage__WEBPACK_IMPORTED_MODULE_14__/* .getDataCookie */ .t)(context);
    if (!dataCookie.isLogin) {
        return {
            redirect: {
                destination: "/auth/login",
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}
const Profile = (props)=>{
    const { 0: isShow , 1: setIsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Index");
    const onChangePage = (data)=>{
        setIsShow(data);
    };
    const userLogin = props.auth.userLogin;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        title: "Profile | xWallet - Send your money without fee",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "",
            style: {
                background: "rgb(99 121 244 / 4%)"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_layout_navbar__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "sidebar mt-5",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_layout_sidebar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `col-md-9`,
                                    children: isShow == "Index" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        changePage: onChangePage,
                                        data: userLogin,
                                        dispatch: props.getUserLogin
                                    }) : isShow == "personalInfo" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_personal_info__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        changePage: onChangePage,
                                        data: userLogin,
                                        dispatch: props.getUserLogin
                                    }) : isShow == "ManagePassword" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_manage_password__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        data: userLogin,
                                        changePage: onChangePage,
                                        dispatch: props.getUserLogin
                                    }) : isShow == "ManagePin" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_manage_pin__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                        changePage: onChangePage,
                                        data: userLogin
                                    }) : isShow == "CheckPin" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_check_pin__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        changePage: onChangePage
                                    }) : isShow == "ManagePhone" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile_manage_phone__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        data: userLogin,
                                        changePage: onChangePage,
                                        dispatch: props.getUserLogin
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_profile__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        changePage: onChangePage
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_layout_footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            ]
        })
    });
};
const mapStateToProps = (state)=>{
    return {
        auth: state.auth
    };
};
const mapDispatchToProps = {
    getUserLogin: stores_action_auth__WEBPACK_IMPORTED_MODULE_13__/* .getUserLogin */ .V
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_12__.connect)(mapStateToProps, mapDispatchToProps)(Profile));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5536:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ getUserLogin),
/* harmony export */   "p": () => (/* binding */ loginUser)
/* harmony export */ });
/* harmony import */ var utils_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7304);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([utils_axios__WEBPACK_IMPORTED_MODULE_0__]);
utils_axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const loginUser = (form)=>{
    return {
        type: "LOGIN",
        payload: utils_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/auth/login", form)
    };
};
const getUserLogin = (id)=>{
    return {
        type: "GETUSER",
        payload: utils_axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/user/profile/${id}`)
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 7486:
/***/ ((module) => {

"use strict";
module.exports = require("next-cookies");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9306:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap/Modal");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

"use strict";
module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [907,699,928,676,664,715,304,36,30,176], () => (__webpack_exec__(2217)));
module.exports = __webpack_exports__;

})();