module.exports = {
  reactStrictMode: true,
  env: {
    URL_BACKEND: 'https://xwallet-backend.dokumensaya.com',
    URL_FRONTEND: 'https://xwallet.dokumensaya.com',
  },
  async rewrites() {
    return [
      {
        source: '/profile', //Pengganti Path (Url Link)
        destination: '/main/profile', //Path Sebenarnya Di Folder
      },
    ];
  },
};
